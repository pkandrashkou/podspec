//
//  RGLCLoggingViewController.h
//  FaceSDK
//
//  Created by Pavel Kondrashkov on 5/5/21.
//  Copyright © 2021 Regula. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RGLCLoggingViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
